I dropped this case study on 15 Dec 2020 because ...

It requires a SQL (localDB/express/proper edition) and that was too many steps to configure
using SQL Azure DB. The eShopOnWeb case study has an in-memory database which suffices.

The labs steps have only been tested through module 5 - created/deploy a release, and then the above surfaced.